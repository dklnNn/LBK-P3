# Badanie 9 — Reklama AI

Kompletny pakiet materiałów do eksperymentu okulograficznego porównującego percepcję reklam
wygenerowanych przez sztuczną inteligencję i stworzonych przez człowieka.

Wersja protokołu 1.0 · lipiec 2026

---

## Co jest w pakiecie

| Plik / katalog | Zawartość | Format |
|---|---|---|
| `Badanie9_Reklama_AI_prezentacja.pptx` | Prezentacja główna — 115 slajdów: scenariusz eksperymentu, przegląd literatury, hipotezy, protokół sesji ekran po ekranie, plan analizy, instrukcja dla eksperymentatora, checklisty, rozszerzenia | PowerPoint |
| `Zalacznik_A_Preregistracja_OSF.docx` | Gotowy formularz prerejestracji w standardzie OSF Prereg — do uzupełnienia pól metadanych i wklejenia | Word, 12 s. |
| `Zalacznik_B_Kwestionariusze_i_zgody.docx` | Informacja o badaniu, formularz zgody, ankieta wstępna, skale po każdej reklamie, 20 pytań pamięciowych, test rozpoznaniowy, kwestionariusze końcowe, skrypt debriefingu, karta sesji | Word, 11 s. |
| `Zalacznik_C_Baza_danych_codebook.xlsx` | 9 arkuszy: codebook (61 zmiennych), matryca bodźców, koordynaty AOI, opis AOI, pytania pamięciowe, sekwencje V1–V4 dla 60 uczestników, plan kodowania, karta sesji | Excel |
| `Zalacznik_D_Bodzce_prompty_i_briefy.docx` | Zasady konstrukcji par, procedura produkcji, kontrola cech niskopoziomowych, licencje, 20 kart par: opis sceny, brief dla grafika, prompt generatywny z promptem negatywnym, karta produkcyjna | Word, 23 s. |
| `bodzce/makiety/` | 40 makiet referencyjnych 1920 × 1080 px — geometria wszystkich elementów | PNG |
| `bodzce/makiety_aoi/` | 40 makiet z naniesionymi obszarami zainteresowania — wzór do wprowadzania AOI w InsightLab | PNG |
| `bodzce/matryca_bodzcow.csv` | Specyfikacja 40 bodźców | CSV |
| `bodzce/aoi_koordynaty.csv` | 478 wierszy: współrzędne wszystkich AOI w pikselach | CSV |
| `bodzce/sekwencje_V1-V4.csv` | 3120 wierszy: gotowe sekwencje prezentacji dla 60 uczestników | CSV |
| `skrypty/` | Pipeline analityczny w Pythonie i R | .py / .R |

---

## Skrypty

| Skrypt | Co robi | Status |
|---|---|---|
| `00_dane_syntetyczne.py` | Generuje dane o strukturze eksportu z InsightLab — do przetestowania łańcucha analitycznego przed zbieraniem danych | uruchomiony i sprawdzony |
| `01_preprocessing.py` | Import eksportów, kontrola jakości wg progów a priori, budowa tabel analitycznych (format długi i szeroki) | uruchomiony i sprawdzony |
| `04_ml_klasyfikacja.py` | Klasyfikacja autorstwa ze wzorca skanowania (H9), walidacja leave-one-participant-out, ważność cech | uruchomiony i sprawdzony |
| `kontrola_bodzcow.py` | Pomiar i porównanie luminancji, kontrastu, nasycenia, entropii i gęstości krawędzi w obrębie pary bodźców | uruchomiony i sprawdzony |
| `02_analiza_H1_H8.R` | Modele mieszane dla wszystkich hipotez konfirmacyjnych, kontrasty, TOST, krzywa kalibracji, wykres leśny AOI | **nie uruchomiony** — wymaga R |
| `03_mediacja_moderacja.R` | Mediacja szeregowa (lavaan, bootstrap), mediacja przez uwagę, moderatory indywidualne | **nie uruchomiony** — wymaga R |
| `05_moc_symulacja.R` | Symulacyjna analiza mocy (simr) — uruchomić przed prerejestracją | **nie uruchomiony** — wymaga R |

Skrypty R nie zostały uruchomione, ponieważ środowisko, w którym powstał pakiet, nie miało
zainstalowanego R. Przed pierwszym użyciem należy je przetestować na danych syntetycznych:

```bash
# 1. dane testowe
python skrypty/00_dane_syntetyczne.py --wyjscie /tmp/badanie9_dane --n 12

# 2. preprocessing
python skrypty/01_preprocessing.py --dane /tmp/badanie9_dane

# 3. modele konfirmacyjne (R 4.3+)
BADANIE9_DANE=/tmp/badanie9_dane Rscript skrypty/02_analiza_H1_H8.R

# 4. mediacja i moderacja
BADANIE9_DANE=/tmp/badanie9_dane Rscript skrypty/03_mediacja_moderacja.R

# 5. klasyfikacja wzorców skanowania
python skrypty/04_ml_klasyfikacja.py --dane /tmp/badanie9_dane --wyjscie /tmp/wyniki
```

Wymagane pakiety R: `lme4`, `lmerTest`, `glmmTMB`, `emmeans`, `broom.mixed`, `lavaan`,
`mediation`, `simr`, `performance`, `dplyr`, `tidyr`, `ggplot2`, `readr`, opcjonalnie `ordinal`.
Wymagane pakiety Python: `pandas`, `numpy`, `scikit-learn`, `Pillow`, `matplotlib`, opcjonalnie `shap`.

---

## Cztery kroki, żeby zacząć

1. **Zweryfikować lokalną instalację EyeLogic InsightLab** — pięć pytań z prezentacji (slajd „Co wiemy
   o oprogramowaniu”): liczba punktów kalibracji, algorytm detekcji fiksacji i jego parametry, lista
   metryk AOI liczonych automatycznie, obecność średnicy źrenicy w eksporcie, możliwość importu AOI
   z pliku. Bez tych odpowiedzi nie da się dokończyć konfiguracji ani opisać aparatury w artykule.
2. **Uruchomić produkcję bodźców** według briefów i promptów z załącznika D. To ścieżka krytyczna
   harmonogramu — pilotaż i prerejestracja zależą od zamrożonego zestawu bodźców.
3. **Złożyć wniosek do komisji bioetycznej** wraz z uzasadnieniem zatajenia częściowego (gotowy akapit
   w prezentacji i w załączniku A, punkt 11).
4. **Przeprowadzić pilotaż A i B**, zamrozić zestaw bodźców, złożyć prerejestrację w OSF.

---

## Uwagi o źródłach

Przegląd literatury obejmuje 57 pozycji. Metadane każdej z nich zostały zweryfikowane w Crossref lub
na stronie wydawcy. Trzy pozycje są oznaczone jako częściowo zweryfikowane (pełna lista autorów lub
numer tomu do potwierdzenia) — są to: Bruns i Kopka (2025, *Journal of Advertising*),
Miniukovich i Figl (2023, *International Journal of Human-Computer Studies*) oraz
Mori (1970/2012, *IEEE Robotics & Automation Magazine*). Przed złożeniem artykułu należy uzupełnić
ich metadane.

Informacje o oprogramowaniu EyeLogic InsightLab pochodzą z dokumentacji producenta. Elementy, których
producent nie publikuje (parametry kalibracji, algorytm detekcji fiksacji, pełna lista metryk AOI,
obecność średnicy źrenicy w eksporcie, import AOI z pliku), są w prezentacji jawnie oznaczone jako
wymagające weryfikacji w lokalnej instalacji.

Makiety bodźców to szablony geometryczne, a nie gotowe reklamy: definiują pozycje wszystkich elementów
i granice obszarów AOI. Warstwę obrazową — fotografię (zestaw A) albo wyjście generatora (zestaw B) —
produkuje zespół według załącznika D.
