# =============================================================================
# Badanie 9 — Reklama AI
# 02_analiza_H1_H8.R — modele konfirmacyjne dla hipotez H1–H8
#
# Wejście : badanie9_dane/05_derived/dane_analityczne_long.csv
#           badanie9_dane/05_derived/dane_analityczne_proby.csv
# Wyjście : wyniki/H1..H8_*.csv, wyniki/ryciny/*.png
#
# Wszystkie modele odpowiadają specyfikacji z prerejestracji (załącznik A, punkt 9).
# Kolejność upraszczania struktury efektów losowych przy braku zbieżności:
#   (1) usunięcie korelacji, (2) usunięcie nachylenia dla kategorii,
#   (3) usunięcie nachylenia dla autorstwa. Każde uproszczenie jest raportowane.
# =============================================================================

pakiety <- c("lme4", "lmerTest", "glmmTMB", "emmeans", "performance",
             "dplyr", "tidyr", "ggplot2", "broom.mixed", "readr")
brak <- pakiety[!pakiety %in% rownames(installed.packages())]
if (length(brak)) install.packages(brak, repos = "https://cloud.r-project.org")
invisible(lapply(pakiety, library, character.only = TRUE))

KAT <- Sys.getenv("BADANIE9_DANE", "badanie9_dane")
dir.create("wyniki/ryciny", recursive = TRUE, showWarnings = FALSE)

dl <- read_csv(file.path(KAT, "05_derived", "dane_analityczne_long.csv"), show_col_types = FALSE)
dp <- read_csv(file.path(KAT, "05_derived", "dane_analityczne_proby.csv"), show_col_types = FALSE)

dl <- dl %>% mutate(
  autorstwo = factor(wariant, levels = c("H", "AI")),
  kategoria = factor(kategoria),
  aoi       = factor(aoi),
  blok      = factor(blok),
  uczestnik = factor(id_uczestnika),
  para      = factor(para))
contrasts(dl$autorstwo) <- c(-0.5, 0.5)          # kontrast sumaryczny
contrasts(dl$kategoria) <- contr.helmert(nlevels(dl$kategoria))

dp <- dp %>% mutate(
  autorstwo = factor(wariant, levels = c("H", "AI")),
  kategoria = factor(kategoria), blok = factor(blok),
  uczestnik = factor(id_uczestnika), para = factor(para))
contrasts(dp$autorstwo) <- c(-0.5, 0.5)

# --------------------------------------------------------------- funkcje pomocnicze
dopasuj <- function(formula_pelna, dane, rodzina = NULL) {
  # próbuje modelu maksymalnego, potem kolejnych uproszczeń; zwraca model i informację
  warianty <- list(
    pelny  = formula_pelna,
    bez_kor = update(formula_pelna, . ~ . - (1 + autorstwo | uczestnik) + (1 | uczestnik) + (0 + autorstwo | uczestnik)),
    bez_nachylen = update(formula_pelna, . ~ . - (1 + autorstwo | uczestnik) + (1 | uczestnik)))
  for (nazwa in names(warianty)) {
    m <- tryCatch({
      if (is.null(rodzina)) lmer(warianty[[nazwa]], data = dane, REML = TRUE,
                                 control = lmerControl(optimizer = "bobyqa"))
      else glmer(warianty[[nazwa]], data = dane, family = rodzina,
                 control = glmerControl(optimizer = "bobyqa"))
    }, error = function(e) NULL, warning = function(w) NULL)
    if (!is.null(m) && (is.null(m@optinfo$conv$lme4$messages))) {
      message(sprintf("  struktura efektów losowych: %s", nazwa))
      attr(m, "struktura") <- nazwa
      return(m)
    }
  }
  stop("Żaden wariant modelu nie osiągnął zbieżności — sprawdź dane.")
}

zapisz <- function(model, plik, opis) {
  tab <- broom.mixed::tidy(model, effects = "fixed", conf.int = TRUE)
  tab$model <- opis
  write_csv(tab, file.path("wyniki", plik))
  print(tab, n = 50)
  invisible(tab)
}

holm <- function(p) p.adjust(p, method = "holm")

# =============================================================================
# H1 — globalne wzorce eksploracji
# =============================================================================
message("\n=== H1: dyspersja, entropia przejść, udział czasu poza AOI ===")
h1_miary <- c("dyspersja", "entropia_przejsc", "czas_w_tle_logit")
h1_p <- c()
for (miara in h1_miary) {
  f <- as.formula(paste(miara, "~ autorstwo * kategoria + blok + nr_proby_z +",
                        "(1 + autorstwo | uczestnik) + (1 | para)"))
  m <- dopasuj(f, dp)
  s <- summary(m)$coefficients
  h1_p <- c(h1_p, s["autorstwo1", "Pr(>|t|)"])
  zapisz(m, sprintf("H1_%s.csv", miara), miara)
  # wielkość efektu jako d z średnich brzegowych
  em <- emmeans(m, ~ autorstwo)
  print(pairs(em))
}
names(h1_p) <- h1_miary
print(data.frame(miara = h1_miary, p = h1_p, p_holm = holm(h1_p)))

# =============================================================================
# H2 — obraz vs tekst (czas do pierwszej fiksacji)
# =============================================================================
message("\n=== H2: log(TTFF) ~ autorstwo × typ elementu ===")
d2 <- dl %>% filter(typ_elementu %in% c("tekstowy", "obrazowy"), !is.na(log_ttff)) %>%
  mutate(typ_elementu = factor(typ_elementu, levels = c("tekstowy", "obrazowy")))
contrasts(d2$typ_elementu) <- c(-0.5, 0.5)
m2 <- dopasuj(log_ttff ~ autorstwo * typ_elementu + kategoria + blok + nr_proby_z + log_pow_aoi +
                (1 + autorstwo | uczestnik) + (1 | para), d2)
zapisz(m2, "H2_ttff.csv", "log(TTFF) ~ autorstwo * typ_elementu")
print(emmeans(m2, pairwise ~ autorstwo | typ_elementu))

# =============================================================================
# H3 — estetyka wyżej, naturalność niżej
# =============================================================================
message("\n=== H3: oceny deklaratywne ===")
d3 <- dp %>%
  select(uczestnik, para, autorstwo, kategoria, blok, nr_proby_z,
         q1_atrakcyjnosc, q2_estetyka, q3_zaufanie, q10_naturalnosc, q11_autentycznosc) %>%
  pivot_longer(starts_with("q"), names_to = "skala", values_to = "ocena") %>%
  filter(!is.na(ocena)) %>%
  mutate(typ_skali = ifelse(skala %in% c("q1_atrakcyjnosc", "q2_estetyka"),
                            "estetyczna", "autentycznosciowa"),
         typ_skali = factor(typ_skali, levels = c("autentycznosciowa", "estetyczna")))
contrasts(d3$typ_skali) <- c(-0.5, 0.5)
m3 <- dopasuj(ocena ~ autorstwo * typ_skali + kategoria + blok + nr_proby_z +
                (1 + autorstwo | uczestnik) + (1 | para), d3)
zapisz(m3, "H3_oceny.csv", "ocena ~ autorstwo * typ_skali")
print(emmeans(m3, pairwise ~ autorstwo | typ_skali))
# analiza wrażliwości: kumulacyjny model porządkowy
if (requireNamespace("ordinal", quietly = TRUE)) {
  m3o <- ordinal::clmm(factor(ocena) ~ autorstwo * typ_skali + (1 | uczestnik), data = d3)
  capture.output(summary(m3o), file = "wyniki/H3_model_porzadkowy.txt")
}

# =============================================================================
# H4 — trafność rozpoznania autorstwa
# =============================================================================
message("\n=== H4: trafność rozpoznania ===")
d4 <- dp %>% filter(blok %in% c("2", "3"), !is.na(q6_poprawnosc))
m4 <- glmer(q6_poprawnosc ~ autorstwo * kategoria + nr_proby_z + (1 | uczestnik) + (1 | para),
            data = d4, family = binomial, control = glmerControl(optimizer = "bobyqa"))
zapisz(m4, "H4_detekcja.csv", "poprawność ~ autorstwo * kategoria")
b0 <- fixef(m4)["(Intercept)"]; se0 <- sqrt(vcov(m4)["(Intercept)", "(Intercept)"])
traf <- plogis(b0); ci <- plogis(b0 + c(-1.96, 1.96) * se0)
cat(sprintf("Trafność ogólna: %.3f  95%% CI [%.3f; %.3f]  (kryterium H4: górna granica < 0,65)\n",
            traf, ci[1], ci[2]))
# teoria detekcji sygnału
sdt <- d4 %>% group_by(uczestnik) %>% summarise(
  H = mean(q6_autorstwo == 2 & wariant == "AI", na.rm = TRUE),
  FA = mean(q6_autorstwo == 2 & wariant == "H", na.rm = TRUE), .groups = "drop") %>%
  mutate(H = pmin(pmax(H, .01), .99), FA = pmin(pmax(FA, .01), .99),
         d_prime = qnorm(H) - qnorm(FA), c_kryt = -0.5 * (qnorm(H) + qnorm(FA)))
write_csv(sdt, "wyniki/H4_sdt.csv")
print(summary(sdt[, c("d_prime", "c_kryt")]))

# =============================================================================
# H5 — kalibracja pewności
# =============================================================================
message("\n=== H5: pewność a trafność ===")
d5 <- d4 %>% filter(!is.na(q7_pewnosc_c))
m5 <- glmer(q6_poprawnosc ~ q7_pewnosc_c * autorstwo + (1 + q7_pewnosc_c | uczestnik),
            data = d5, family = binomial, control = glmerControl(optimizer = "bobyqa"))
zapisz(m5, "H5_kalibracja.csv", "poprawność ~ pewność (centrowana) × autorstwo")
est <- fixef(m5)["q7_pewnosc_c"]; se <- sqrt(vcov(m5)["q7_pewnosc_c", "q7_pewnosc_c"])
cat(sprintf("OR na 10 p.p. pewności: %.3f\n", exp(est * 10)))
# test równoważności (TOST) wobec granic OR ∈ [0,90; 1,11] na 10 punktów procentowych
gr <- log(1.11) / 10                       # granica równoważności na skali logitu
z_gorna <- (est - gr) / se                 # H0: efekt >= gr
z_dolna <- (est + gr) / se                 # H0: efkt <= -gr
p_gorna <- pnorm(z_gorna)                  # jednostronny, lewy ogon
p_dolna <- 1 - pnorm(z_dolna)              # jednostronny, prawy ogon
p_tost  <- max(p_gorna, p_dolna)
cat(sprintf("TOST (granice OR 0,90-1,11 na 10 p.p.): p = %.4f — %s\n", p_tost,
            ifelse(p_tost < 0.05, "efekt statystycznie równoważny zeru (H5 potwierdzona)",
                   "brak dowodu równoważności — wynik nierozstrzygający")))
write_csv(data.frame(estymata = est, se = se, granica_logit = gr,
                     p_tost = p_tost, or_10pp = exp(est * 10)), "wyniki/H5_tost.csv")
# krzywa kalibracji i ECE
kal <- d5 %>% mutate(kosz = cut(q7_pewnosc, breaks = seq(0, 100, 10), include.lowest = TRUE)) %>%
  group_by(kosz) %>% summarise(n = n(), pewnosc = mean(q7_pewnosc) / 100,
                               trafnosc = mean(q6_poprawnosc), .groups = "drop")
ece <- sum(kal$n / sum(kal$n) * abs(kal$pewnosc - kal$trafnosc))
cat(sprintf("Expected Calibration Error: %.3f\n", ece))
write_csv(kal, "wyniki/H5_krzywa_kalibracji.csv")
ggplot(kal, aes(pewnosc, trafnosc)) +
  geom_abline(linetype = 2, colour = "grey50") +
  geom_line(colour = "#E4572E", linewidth = 1) + geom_point(aes(size = n), colour = "#2D3A8C") +
  coord_equal(xlim = c(0, 1), ylim = c(0, 1)) +
  labs(x = "Deklarowana pewność", y = "Rzeczywista trafność",
       title = "Krzywa kalibracji rozpoznania autorstwa",
       subtitle = sprintf("ECE = %.3f; przekątna = kalibracja idealna", ece)) +
  theme_minimal(base_size = 12)
ggsave("wyniki/ryciny/H5_kalibracja.png", width = 6, height = 6, dpi = 200)

# =============================================================================
# H6 — różnice na poziomie AOI
# =============================================================================
message("\n=== H6: autorstwo × AOI ===")
AOI_TEST <- c("TWARZ", "DLONIE", "TEKST", "LOGO", "PRODUKT")
d6 <- dl %>% filter(aoi %in% AOI_TEST) %>% mutate(aoi = droplevels(aoi))
m6 <- dopasuj(sqrt(dwell_time) ~ autorstwo * aoi + kategoria + blok + nr_proby_z + log_pow_aoi +
                (1 + autorstwo | uczestnik) + (1 | para), d6)
zapisz(m6, "H6_dwell_aoi.csv", "sqrt(dwell) ~ autorstwo * AOI")
kontr <- as.data.frame(pairs(emmeans(m6, ~ autorstwo | aoi)))
kontr$p_holm <- holm(kontr$p.value)
write_csv(kontr, "wyniki/H6_kontrasty.csv"); print(kontr)
# rewizyty — model Poissona
m6r <- glmer(rewizyty ~ autorstwo * aoi + log_pow_aoi + (1 | uczestnik) + (1 | para),
             data = d6, family = poisson, control = glmerControl(optimizer = "bobyqa"))
zapisz(m6r, "H6_rewizyty.csv", "rewizyty ~ autorstwo * AOI")
# rycina główna: wykres leśny różnic dla wszystkich AOI
lesny <- dl %>% group_by(aoi) %>% group_modify(~{
  m <- tryCatch(lmer(sqrt(dwell_time) ~ autorstwo + log_pow_aoi + (1 | uczestnik) + (1 | para),
                     data = .x, control = lmerControl(optimizer = "bobyqa")), error = function(e) NULL)
  if (is.null(m)) return(tibble(est = NA, lo = NA, hi = NA))
  ci <- confint(m, parm = "autorstwo1", method = "Wald")
  tibble(est = fixef(m)["autorstwo1"], lo = ci[1], hi = ci[2])
}) %>% ungroup()
write_csv(lesny, "wyniki/H6_wykres_lesny.csv")
ggplot(lesny, aes(x = est, y = reorder(aoi, est))) +
  geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
  geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0.2, colour = "#2D3A8C") +
  geom_point(size = 2.5, colour = "#E4572E") +
  labs(x = "Różnica AI − człowiek (√ms)", y = NULL,
       title = "Różnice w dwell time według obszaru zainteresowania") +
  theme_minimal(base_size = 12)
ggsave("wyniki/ryciny/H6_wykres_lesny.png", width = 7, height = 5, dpi = 200)

# =============================================================================
# H7 — moderacja przez doświadczenie z AI
# =============================================================================
message("\n=== H7: moderacja doświadczeniem z AI ===")
d7 <- dl %>% filter(aoi %in% c("TWARZ", "DLONIE"), !is.na(log_ttff), !is.na(ai_czestotliwosc_z))
m7 <- dopasuj(log_ttff ~ autorstwo * ai_czestotliwosc_z + aoi + kategoria + log_pow_aoi +
                (1 + autorstwo | uczestnik) + (1 | para), d7)
zapisz(m7, "H7_moderacja_ttff.csv", "log(TTFF) ~ autorstwo × doświadczenie AI")
print(emtrends(m7, ~ autorstwo, var = "ai_czestotliwosc_z"))
m7b <- glmer(q6_poprawnosc ~ autorstwo * ai_czestotliwosc_z + (1 | uczestnik) + (1 | para),
             data = d4 %>% filter(!is.na(ai_czestotliwosc_z)), family = binomial,
             control = glmerControl(optimizer = "bobyqa"))
zapisz(m7b, "H7_moderacja_trafnosc.csv", "poprawność ~ autorstwo × doświadczenie AI")

# =============================================================================
# H8 — pamięć: AOI kluczowe vs czas całkowity
# =============================================================================
message("\n=== H8: predyktory pamięci ===")
d8 <- dp %>% filter(!is.na(q9_poprawnosc)) %>%
  mutate(dwell_klucz_z = scale(dwell_aoi_kluczowe)[, 1],
         dwell_total_z = scale(dwell_total)[, 1])
m8_aoi   <- glmer(q9_poprawnosc ~ dwell_klucz_z + autorstwo + (1 | uczestnik) + (1 | para),
                  data = d8, family = binomial, control = glmerControl(optimizer = "bobyqa"))
m8_total <- glmer(q9_poprawnosc ~ dwell_total_z + autorstwo + (1 | uczestnik) + (1 | para),
                  data = d8, family = binomial, control = glmerControl(optimizer = "bobyqa"))
zapisz(m8_aoi, "H8_model_aoi.csv", "pamięć ~ dwell na AOI kluczowych")
zapisz(m8_total, "H8_model_total.csv", "pamięć ~ całkowity dwell time")
por <- data.frame(model = c("AOI kluczowe", "czas całkowity"),
                  AIC = c(AIC(m8_aoi), AIC(m8_total)), BIC = c(BIC(m8_aoi), BIC(m8_total)))
por$delta_AIC <- por$AIC - min(por$AIC)
write_csv(por, "wyniki/H8_porownanie_modeli.csv"); print(por)
cat(sprintf("Kryterium H8: ΔAIC = %.2f (wymagane > 2 na korzyść modelu AOI)\n",
            por$AIC[2] - por$AIC[1]))

message("\nGotowe. Wyniki w katalogu wyniki/.")
