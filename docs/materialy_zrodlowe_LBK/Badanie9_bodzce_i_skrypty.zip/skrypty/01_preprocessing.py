#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Badanie 9 — Reklama AI
01_preprocessing.py — import eksportów z EyeLogic InsightLab, kontrola jakości,
budowa tabel analitycznych (format długi i szeroki).

Wejście  : badanie9_dane/01_raw, 02_fixations, 03_aoi, 04_survey, 00_meta
Wyjście  : badanie9_dane/05_derived/dane_analityczne_long.csv
           badanie9_dane/05_derived/dane_analityczne_proby.csv
           badanie9_dane/05_derived/raport_jakosci.csv

Wszystkie progi są ustalone a priori i zapisane w prerejestracji (załącznik A, punkt 8).
Uruchomienie:  python 01_preprocessing.py --dane /sciezka/badanie9_dane
"""
import argparse, os, sys, math, json
import numpy as np
import pandas as pd

# ----------------------------------------------------------------- PROGI A PRIORI
PROG = dict(
    utrata_proby=0.25,          # odrzucenie próby przy utracie sygnału > 25%
    utrata_uczestnik=0.20,      # odrzucenie uczestnika przy medianie > 20%
    kalibracja_max=1.5,         # odrzucenie uczestnika przy błędzie > 1,5 stopnia
    min_fiksacji=3,             # odrzucenie próby przy < 3 fiksacjach
    min_czas_fiksacji=60,       # scalanie fiksacji krótszych niż 60 ms
    okno_zrenica=(500, 1500),   # okno pomiaru reakcji źrenicy (ms)
    baza_zrenica=200,           # długość linii bazowej przed bodźcem (ms)
)
AOI_KLUCZOWE = ["PRODUKT", "MARKA", "LOGO"]
AOI_TEKSTOWE = ["SLOGAN", "TEKST", "CENA", "MARKA"]
AOI_OBRAZOWE = ["PRODUKT", "TWARZ", "DLONIE"]


# ----------------------------------------------------------------- WCZYTANIE
def wczytaj(kat):
    """Scala eksporty wszystkich uczestników. Nazwy plików wg konwencji z protokołu."""
    def zbierz(podkat, wzorzec):
        pliki = sorted(f for f in os.listdir(os.path.join(kat, podkat)) if wzorzec in f)
        if not pliki:
            raise FileNotFoundError("Brak plików %s w %s" % (wzorzec, podkat))
        ramki = []
        for f in pliki:
            sciezka = os.path.join(kat, podkat, f)
            df = pd.read_csv(sciezka, sep=None, engine="python")
            df["id_uczestnika"] = f.split("_")[0] + "_" + f.split("_")[1]
            ramki.append(df)
        return pd.concat(ramki, ignore_index=True)

    fix = zbierz("02_fixations", "_fix")
    resp = zbierz("04_survey", "_resp")
    meta_b = pd.read_csv(os.path.join(kat, "00_meta", "matryca_bodzcow.csv"))
    meta_a = pd.read_csv(os.path.join(kat, "00_meta", "aoi_koordynaty.csv"))
    ucz = pd.read_csv(os.path.join(kat, "00_meta", "uczestnicy.csv"))
    return fix, resp, meta_b, meta_a, ucz


# ----------------------------------------------------------------- KONTROLA JAKOŚCI
def kontrola_jakosci(fix, resp, ucz):
    """Zwraca (fix, resp, ucz, raport) po zastosowaniu progów a priori."""
    raport = []

    # 1. uczestnicy: błąd kalibracji i mediana utraty sygnału
    zle_kal = ucz.loc[ucz["blad_kalibracji"] > PROG["kalibracja_max"], "id_uczestnika"]
    zle_syg = ucz.loc[ucz["utrata_sygnalu_med"] > PROG["utrata_uczestnik"], "id_uczestnika"]
    usun_ucz = set(zle_kal) | set(zle_syg)
    for u in sorted(usun_ucz):
        powod = []
        if u in set(zle_kal): powod.append("blad_kalibracji")
        if u in set(zle_syg): powod.append("utrata_sygnalu")
        raport.append(dict(poziom="uczestnik", jednostka=u, powod="+".join(powod)))

    fix = fix[~fix["id_uczestnika"].isin(usun_ucz)].copy()
    resp = resp[~resp["id_uczestnika"].isin(usun_ucz)].copy()
    ucz = ucz[~ucz["id_uczestnika"].isin(usun_ucz)].copy()

    # 2. fiksacje: scalanie krótkich, odrzucanie poza ekranem, odrzucanie pierwszej
    fix = fix[(fix["x"].between(0, 1920)) & (fix["y"].between(0, 1080))]
    fix = fix.sort_values(["id_uczestnika", "stimulus_id", "nr_fiksacji"])
    fix = fix[fix["czas_trwania"] >= PROG["min_czas_fiksacji"]]
    fix = fix[fix["nr_fiksacji"] > 1]           # pierwsza fiksacja = artefakt pozycji startowej

    # 3. próby: utrata sygnału i liczba fiksacji
    if "utrata_sygnalu" in resp.columns:
        zle = resp[resp["utrata_sygnalu"] > PROG["utrata_proby"]][["id_uczestnika", "stimulus_id"]]
        for _, r in zle.iterrows():
            raport.append(dict(poziom="proba", jednostka="%s|%s" % (r.id_uczestnika, r.stimulus_id),
                               powod="utrata_sygnalu"))
        resp = resp[resp["utrata_sygnalu"] <= PROG["utrata_proby"]]

    licz = fix.groupby(["id_uczestnika", "stimulus_id"]).size().rename("n_fix").reset_index()
    male = licz[licz["n_fix"] < PROG["min_fiksacji"]]
    for _, r in male.iterrows():
        raport.append(dict(poziom="proba", jednostka="%s|%s" % (r.id_uczestnika, r.stimulus_id),
                           powod="za_malo_fiksacji"))
    klucz_ok = set(zip(licz.loc[licz["n_fix"] >= PROG["min_fiksacji"], "id_uczestnika"],
                       licz.loc[licz["n_fix"] >= PROG["min_fiksacji"], "stimulus_id"]))
    fix = fix[[k in klucz_ok for k in zip(fix["id_uczestnika"], fix["stimulus_id"])]]
    resp = resp[[k in klucz_ok for k in zip(resp["id_uczestnika"], resp["stimulus_id"])]]

    return fix, resp, ucz, pd.DataFrame(raport)


# ----------------------------------------------------------------- MIARY
def metryki_aoi(fix, meta_a):
    """Buduje tabelę uczestnik × bodziec × AOI z pełnym zestawem miar okoruchowych.
    Uwaga: raportujemy osobno liczbę i czas trwania fiksacji (Orquin i Holmqvist, 2018)."""
    aoi_lista = meta_a[["stimulus_id", "aoi", "powierzchnia_proc"]].drop_duplicates()
    fixa = fix.dropna(subset=["aoi_przypisane"])

    g = fixa.groupby(["id_uczestnika", "stimulus_id", "aoi_przypisane"])
    tab = g.agg(dwell_time=("czas_trwania", "sum"),
                liczba_fiksacji=("czas_trwania", "size"),
                sredni_czas_fiksacji=("czas_trwania", "mean"),
                ttff=("start_ms", "min")).reset_index()
    tab = tab.rename(columns={"aoi_przypisane": "aoi"})

    # rewizyty: liczba wejść do AOI po jego wcześniejszym opuszczeniu
    rekordy = []
    for (u, s), grupa in fixa.groupby(["id_uczestnika", "stimulus_id"]):
        seq = grupa.sort_values("nr_fiksacji")["aoi_przypisane"].tolist()
        wejscia, prev = {}, None
        for aoi in seq:
            if pd.notna(aoi) and aoi != prev:
                wejscia[aoi] = wejscia.get(aoi, 0) + 1
            prev = aoi
        for aoi, n in wejscia.items():
            rekordy.append(dict(id_uczestnika=u, stimulus_id=s, aoi=aoi, wejscia=n))
    rewizyty = pd.DataFrame(rekordy, columns=["id_uczestnika", "stimulus_id", "aoi", "wejscia"])
    rewizyty["rewizyty"] = rewizyty["wejscia"] - 1
    tab = tab.merge(rewizyty[["id_uczestnika", "stimulus_id", "aoi", "rewizyty"]],
                    on=["id_uczestnika", "stimulus_id", "aoi"], how="left")

    # uzupełnienie AOI bez ani jednej fiksacji (dwell = 0, ttff = NA -> model hurdle)
    pary = tab[["id_uczestnika", "stimulus_id"]].drop_duplicates()
    pelne = pary.merge(aoi_lista, on="stimulus_id")
    tab = pelne.merge(tab, on=["id_uczestnika", "stimulus_id", "aoi"], how="left")
    for k in ["dwell_time", "liczba_fiksacji", "rewizyty"]:
        tab[k] = tab[k].fillna(0)
    tab["log_pow_aoi"] = np.log(tab["powierzchnia_proc"].clip(lower=0.01))
    tab["log_ttff"] = np.log(tab["ttff"] + 1)
    return tab


def metryki_proby(fix, meta_a):
    """Miary globalne na poziomie próby: dyspersja, entropia przejść, udział czasu poza AOI."""
    wynik = []
    for (u, s), g in fix.groupby(["id_uczestnika", "stimulus_id"]):
        g = g.sort_values("nr_fiksacji")
        dysp = float(np.mean([g["x"].std(ddof=1), g["y"].std(ddof=1)])) if len(g) > 1 else np.nan
        seq = g["aoi_przypisane"].fillna("TLO").tolist()
        przejscia = [(seq[i], seq[i + 1]) for i in range(len(seq) - 1) if seq[i] != seq[i + 1]]
        if przejscia:
            _, licz = np.unique(["%s>%s" % p for p in przejscia], return_counts=True)
            p = licz / licz.sum()
            entropia = float(-(p * np.log2(p)).sum())
        else:
            entropia = 0.0
        czas_total = float(g["czas_trwania"].sum())
        czas_tlo = float(g.loc[g["aoi_przypisane"].isna() | (g["aoi_przypisane"] == "TLO"), "czas_trwania"].sum())
        czas_klucz = float(g.loc[g["aoi_przypisane"].isin(AOI_KLUCZOWE), "czas_trwania"].sum())
        czas_tekst = float(g.loc[g["aoi_przypisane"].isin(AOI_TEKSTOWE), "czas_trwania"].sum())
        czas_obraz = float(g.loc[g["aoi_przypisane"].isin(AOI_OBRAZOWE), "czas_trwania"].sum())
        wynik.append(dict(id_uczestnika=u, stimulus_id=s,
                          liczba_fiksacji_total=len(g), dyspersja=dysp,
                          entropia_przejsc=entropia, liczba_przejsc=len(przejscia),
                          dwell_total=czas_total,
                          czas_w_tle_proc=czas_tlo / czas_total if czas_total else np.nan,
                          dwell_aoi_kluczowe=czas_klucz,
                          dwell_tekstowe=czas_tekst, dwell_obrazowe=czas_obraz))
    return pd.DataFrame(wynik)


def logit(p, eps=1e-3):
    p = np.clip(p, eps, 1 - eps)
    return np.log(p / (1 - p))


# ----------------------------------------------------------------- ZŁĄCZENIE
def zloz(tab_aoi, tab_proby, resp, meta_b, ucz):
    df = tab_aoi.merge(tab_proby, on=["id_uczestnika", "stimulus_id"], how="left")
    df = df.merge(meta_b, on="stimulus_id", how="left")
    df = df.merge(resp, on=["id_uczestnika", "stimulus_id"], how="left", suffixes=("", "_r"))
    df = df.merge(ucz, on="id_uczestnika", how="left", suffixes=("", "_u"))

    # kontrasty i standaryzacje przewidziane w planie analizy
    df["autorstwo_c"] = np.where(df["wariant"].eq("AI"), 0.5, -0.5)
    df["typ_elementu"] = np.select(
        [df["aoi"].isin(AOI_TEKSTOWE), df["aoi"].isin(AOI_OBRAZOWE)],
        ["tekstowy", "obrazowy"], default="inny")
    if "nr_proby" in df.columns:
        df["nr_proby_z"] = (df["nr_proby"] - df["nr_proby"].mean()) / df["nr_proby"].std(ddof=1)
    for k in ["ai_czestotliwosc", "gaais_sr", "mails_sr", "wiek"]:
        if k in df.columns:
            df[k + "_z"] = (df[k] - df[k].mean()) / df[k].std(ddof=1)
    if "q7_pewnosc" in df.columns:
        df["q7_pewnosc_c"] = df["q7_pewnosc"] - df.groupby("id_uczestnika")["q7_pewnosc"].transform("mean")
    if "czas_w_tle_proc" in df.columns:
        df["czas_w_tle_logit"] = logit(df["czas_w_tle_proc"])
    return df


# ----------------------------------------------------------------- MAIN
def main():
    ap = argparse.ArgumentParser(description="Preprocessing danych Badania 9")
    ap.add_argument("--dane", required=True, help="katalog badanie9_dane")
    ap.add_argument("--wyjscie", default=None, help="katalog wyjściowy (domyślnie <dane>/05_derived)")
    a = ap.parse_args()
    out = a.wyjscie or os.path.join(a.dane, "05_derived")
    os.makedirs(out, exist_ok=True)

    fix, resp, meta_b, meta_a, ucz = wczytaj(a.dane)
    print("Wczytano: %d fiksacji, %d odpowiedzi, %d uczestników" % (len(fix), len(resp), len(ucz)))

    fix, resp, ucz, raport = kontrola_jakosci(fix, resp, ucz)
    print("Po kontroli jakości: %d fiksacji, %d odpowiedzi, %d uczestników" % (len(fix), len(resp), len(ucz)))
    print("Odrzucono: %d uczestników, %d prób"
          % ((raport["poziom"] == "uczestnik").sum() if len(raport) else 0,
             (raport["poziom"] == "proba").sum() if len(raport) else 0))

    tab_aoi = metryki_aoi(fix, meta_a)
    tab_proby = metryki_proby(fix, meta_a)
    dl = zloz(tab_aoi, tab_proby, resp, meta_b, ucz)

    dl.to_csv(os.path.join(out, "dane_analityczne_long.csv"), index=False, encoding="utf-8")
    proby = dl.drop_duplicates(subset=["id_uczestnika", "stimulus_id"]).drop(
        columns=[c for c in ["aoi", "dwell_time", "liczba_fiksacji", "ttff", "log_ttff",
                             "rewizyty", "sredni_czas_fiksacji", "powierzchnia_proc",
                             "log_pow_aoi", "typ_elementu"] if c in dl.columns])
    proby.to_csv(os.path.join(out, "dane_analityczne_proby.csv"), index=False, encoding="utf-8")
    raport.to_csv(os.path.join(out, "raport_jakosci.csv"), index=False, encoding="utf-8")

    print("Zapisano:")
    print("  dane_analityczne_long.csv  — %d wierszy (uczestnik × bodziec × AOI)" % len(dl))
    print("  dane_analityczne_proby.csv — %d wierszy (uczestnik × bodziec)" % len(proby))
    print("  raport_jakosci.csv         — %d pozycji" % len(raport))


if __name__ == "__main__":
    main()
