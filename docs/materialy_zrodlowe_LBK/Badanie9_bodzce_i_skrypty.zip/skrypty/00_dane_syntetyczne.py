#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Badanie 9 — Reklama AI
00_dane_syntetyczne.py — generator danych syntetycznych o strukturze identycznej
z eksportem z EyeLogic InsightLab.

Służy do: (a) przetestowania całego łańcucha analitycznego przed zbieraniem danych,
(b) sprawdzenia poprawności konfiguracji eksportu, (c) szkolenia zespołu.
UWAGA: dane są losowe — nie wolno ich mieszać z danymi rzeczywistymi.

Uruchomienie:  python 00_dane_syntetyczne.py --wyjscie /tmp/badanie9_dane --n 12
"""
import argparse, os, csv, math
import numpy as np
import pandas as pd

RNG = np.random.default_rng(20260726)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wyjscie", required=True)
    ap.add_argument("--n", type=int, default=12, help="liczba uczestników")
    ap.add_argument("--meta", default=os.path.join(os.path.dirname(__file__), "..", "bodzce"))
    a = ap.parse_args()

    for d in ["01_raw", "02_fixations", "03_aoi", "04_survey", "00_meta", "05_derived"]:
        os.makedirs(os.path.join(a.wyjscie, d), exist_ok=True)

    mb = pd.read_csv(os.path.join(a.meta, "matryca_bodzcow.csv"))
    ma = pd.read_csv(os.path.join(a.meta, "aoi_koordynaty.csv"))
    mb_out = mb.rename(columns={"zrodlo": "zrodlo_opis"})
    mb_out.to_csv(os.path.join(a.wyjscie, "00_meta", "matryca_bodzcow.csv"), index=False)
    ma.rename(columns={"szer": "szerokosc", "wys": "wysokosc", "pow_proc": "powierzchnia_proc"}) \
      .to_csv(os.path.join(a.wyjscie, "00_meta", "aoi_koordynaty.csv"), index=False)

    aoi_map = {sid: g for sid, g in ma.groupby("stimulus_id")}
    ucz_rows = []

    for i in range(1, a.n + 1):
        uid = "P09_%03d" % i
        ai_freq = int(RNG.integers(1, 8))
        ucz_rows.append(dict(id_uczestnika=uid, wersja_sekwencji="V%d" % (1 + i % 4),
                             wiek=int(RNG.integers(18, 66)), plec=int(RNG.integers(1, 3)),
                             wyksztalcenie=int(RNG.integers(3, 6)), marketing=int(RNG.integers(0, 2)),
                             ai_czestotliwosc=ai_freq, ai_narzedzia_n=int(RNG.integers(0, 6)),
                             ai_samoocena=int(RNG.integers(1, 8)),
                             gaais_sr=round(float(RNG.normal(3.4, 0.6)), 2),
                             mails_sr=round(float(RNG.normal(3.1, 0.7)), 2),
                             heur_masz_sr=round(float(RNG.normal(4.2, 0.8)), 2),
                             blad_kalibracji=round(float(abs(RNG.normal(0.55, 0.25))), 2),
                             utrata_sygnalu_med=round(float(abs(RNG.normal(0.07, 0.04))), 3),
                             podejrzenia_cel=int(RNG.choice([0, 1, 2], p=[0.6, 0.3, 0.1])),
                             status="kompletny"))
        u_offset = RNG.normal(0, 0.25)
        fix_rows, resp_rows = [], []
        bodzce = mb.sample(frac=1, random_state=int(RNG.integers(1e6)))
        for nr, (_, b) in enumerate(bodzce.iterrows(), 1):
            sid = b["stimulus_id"]; ai = (b["wariant"] == "AI")
            blok = 1 if nr <= 20 else 2
            czas_eks = float(np.clip(RNG.normal(5200 + (350 if ai else 0), 1500), 2000, 12000))
            aoi_g = aoi_map[sid]
            n_fix = int(np.clip(RNG.poisson(czas_eks / 260), 3, 60))
            t = 0.0; nrf = 0
            for _ in range(n_fix):
                nrf += 1
                row = aoi_g.sample(1, random_state=int(RNG.integers(1e6))).iloc[0]
                aoi = row["aoi"]
                if aoi in ("TLO", "OBRAZ"):
                    aoi = "TLO" if RNG.random() < 0.6 else "PRODUKT"
                x = float(RNG.uniform(row["x0"], row["x1"])) if aoi != "TLO" else float(RNG.uniform(0, 1920))
                y = float(RNG.uniform(row["y0"], row["y1"])) if aoi != "TLO" else float(RNG.uniform(0, 1080))
                bonus = 45 if (ai and aoi in ("TWARZ", "DLONIE")) else 0
                dur = float(np.clip(RNG.normal(230 + bonus + u_offset * 40, 70), 60, 900))
                fix_rows.append(dict(id_fiksacji="%s_%s_%03d" % (uid, sid, nrf), stimulus_id=sid,
                                     nr_fiksacji=nrf, start_ms=round(t, 1),
                                     czas_trwania=round(dur, 1), x=round(x, 1), y=round(y, 1),
                                     aoi_przypisane=aoi))
                t += dur + float(RNG.normal(45, 12))
                if t > czas_eks: break
            baza = 4.0 + u_offset
            traf_p = 0.58 if ai else 0.55
            odp_auth = 2 if (RNG.random() < traf_p) == ai else 1
            if RNG.random() < 0.15: odp_auth = 3
            popr = np.nan if odp_auth == 3 else int((odp_auth == 2) == ai)
            resp_rows.append(dict(stimulus_id=sid, blok=blok, nr_proby=nr,
                                  czas_ekspozycji=round(czas_eks, 1),
                                  utrata_sygnalu=round(float(abs(RNG.normal(0.06, 0.05))), 3),
                                  q1_atrakcyjnosc=int(np.clip(round(baza + (0.35 if ai else 0) + RNG.normal(0, 1.1)), 1, 7)),
                                  q2_estetyka=int(np.clip(round(baza + (0.45 if ai else 0) + RNG.normal(0, 1.1)), 1, 7)),
                                  q3_zaufanie=int(np.clip(round(baza - (0.20 if ai else 0) + RNG.normal(0, 1.2)), 1, 7)),
                                  q4_intencja=int(np.clip(round(baza - 0.4 + RNG.normal(0, 1.3)), 1, 7)),
                                  q5_pamiec=int(np.clip(round(baza + RNG.normal(0, 1.2)), 1, 7)),
                                  q6_autorstwo=odp_auth, q6_poprawnosc=popr,
                                  q7_pewnosc=int(np.clip(RNG.normal(62, 18), 0, 100)),
                                  q8_element=int(RNG.integers(1, 13)),
                                  q9_poprawnosc=int(RNG.random() < 0.72),
                                  q10_naturalnosc=int(np.clip(round(baza - (0.5 if ai else 0) + RNG.normal(0, 1.2)), 1, 7)),
                                  q11_autentycznosc=int(np.clip(round(baza - (0.45 if ai else 0) + RNG.normal(0, 1.2)), 1, 7)),
                                  rt_q6=round(float(abs(RNG.normal(2600, 900))), 1)))
        pd.DataFrame(fix_rows).to_csv(os.path.join(a.wyjscie, "02_fixations", "%s_fix.csv" % uid), index=False)
        pd.DataFrame(resp_rows).to_csv(os.path.join(a.wyjscie, "04_survey", "%s_resp.csv" % uid), index=False)

    pd.DataFrame(ucz_rows).to_csv(os.path.join(a.wyjscie, "00_meta", "uczestnicy.csv"), index=False)
    print("Wygenerowano dane syntetyczne dla %d uczestników w %s" % (a.n, a.wyjscie))
    print("UWAGA: dane są losowe i służą wyłącznie do testów łańcucha analitycznego.")

if __name__ == "__main__":
    main()
