#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Badanie 9 — Reklama AI
kontrola_bodzcow.py — pomiar i porównanie cech niskopoziomowych w obrębie pary bodźców.

Sprawdza kryteria z załącznika D, punkt 3:
  luminancja, kontrast RMS, nasycenie, temperatura barwna  — różnica < 5%
  entropia obrazu, gęstość krawędzi                        — różnica < 10%

Uruchomienie:  python kontrola_bodzcow.py --katalog bodzce/makiety --wyjscie kontrola.csv
"""
import argparse, os, re, csv
import numpy as np
from PIL import Image

def cechy(sciezka):
    im = Image.open(sciezka).convert("RGB")
    a = np.asarray(im, dtype=np.float64)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
    mx, mn = a.max(axis=2), a.min(axis=2)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-9), 0.0)
    szare = lum.astype(np.uint8)
    hist = np.bincount(szare.ravel(), minlength=256).astype(np.float64)
    p = hist[hist > 0] / hist.sum()
    entropia = float(-(p * np.log2(p)).sum())
    gy, gx = np.gradient(lum)
    krawedzie = np.hypot(gx, gy)
    return dict(
        luminancja=float(lum.mean()),
        kontrast_rms=float(lum.std() / max(lum.mean(), 1e-9)),
        nasycenie=float(np.median(sat)),
        temp_barwna=float(r.mean() / max(b.mean(), 1e-9)),
        entropia=entropia,
        gestosc_krawedzi=float((krawedzie > 25).mean()))

def roznica(x, y):
    d = abs(x - y) / max(abs(x), abs(y), 1e-9)
    return d

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--katalog", required=True, help="katalog z plikami bodźców")
    ap.add_argument("--wyjscie", default="kontrola_bodzcow.csv")
    a = ap.parse_args()

    pliki = [f for f in sorted(os.listdir(a.katalog)) if f.lower().endswith((".png", ".jpg", ".jpeg"))]
    dane = {}
    for f in pliki:
        m = re.match(r"(P\d+)_(H|AI)_", f)
        if not m:
            print("Pomijam plik o nietypowej nazwie: %s" % f); continue
        dane.setdefault(m.group(1), {})[m.group(2)] = cechy(os.path.join(a.katalog, f))

    PROGI = dict(luminancja=0.05, kontrast_rms=0.05, nasycenie=0.05,
                 temp_barwna=0.05, entropia=0.10, gestosc_krawedzi=0.10)
    wiersze, problemy = [], 0
    for para in sorted(dane):
        if len(dane[para]) != 2:
            print("Para %s niekompletna — pomijam." % para); continue
        h, ai = dane[para]["H"], dane[para]["AI"]
        w = {"para": para}
        ok_para = True
        for k, prog in PROGI.items():
            d = roznica(h[k], ai[k])
            w["%s_H" % k] = round(h[k], 4)
            w["%s_AI" % k] = round(ai[k], 4)
            w["%s_roznica" % k] = round(d, 4)
            w["%s_ok" % k] = "TAK" if d <= prog else "NIE"
            if d > prog:
                ok_para = False
        w["para_akceptowana"] = "TAK" if ok_para else "NIE"
        if not ok_para:
            problemy += 1
        wiersze.append(w)

    if wiersze:
        with open(a.wyjscie, "w", newline="", encoding="utf-8-sig") as fh:
            wr = csv.DictWriter(fh, fieldnames=list(wiersze[0].keys()))
            wr.writeheader(); wr.writerows(wiersze)
        print("Sprawdzono %d par. Poza kryterium: %d. Wynik: %s" % (len(wiersze), problemy, a.wyjscie))
        for w in wiersze:
            if w["para_akceptowana"] == "NIE":
                zle = [k.replace("_ok", "") for k, v in w.items() if k.endswith("_ok") and v == "NIE"]
                print("  %s — poza kryterium: %s" % (w["para"], ", ".join(zle)))
    else:
        print("Nie znaleziono kompletnych par.")

if __name__ == "__main__":
    main()
