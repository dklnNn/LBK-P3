#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Badanie 9 — Reklama AI
04_ml_klasyfikacja.py — eksploracyjna klasyfikacja autorstwa reklamy na podstawie
wzorca skanowania (hipoteza H9).

Pytanie: czy wzorzec ruchu oczu niesie informację o autorstwie reklamy nawet wtedy,
gdy uczestnik nie rozpoznaje go świadomie?

Walidacja: leave-one-participant-out. To jest istotne — przy walidacji losowej model
nauczyłby się rozpoznawać osoby, a nie warunki eksperymentalne.

Wejście : badanie9_dane/05_derived/dane_analityczne_long.csv
Wyjście : wyniki/H9_auc.csv, wyniki/H9_waznosc_cech.csv, wyniki/ryciny/H9_*.png
"""
import argparse, os, warnings
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.inspection import permutation_importance

warnings.filterwarnings("ignore")
RNG = 20260726
AOI_WSZYSTKIE = ["LOGO", "MARKA", "SLOGAN", "PRODUKT", "TWARZ", "OCZY",
                 "DLONIE", "CENA", "CTA", "PROMO", "TEKST"]


def cechy(dl):
    """Buduje macierz cech: jeden wiersz = jedna próba (uczestnik × bodziec)."""
    baza = dl.drop_duplicates(subset=["id_uczestnika", "stimulus_id"])[
        ["id_uczestnika", "stimulus_id", "wariant", "kategoria", "blok",
         "dyspersja", "entropia_przejsc", "liczba_przejsc", "liczba_fiksacji_total",
         "dwell_total", "czas_w_tle_proc", "q6_poprawnosc"]].copy()

    for miara in ["dwell_time", "log_ttff", "liczba_fiksacji", "rewizyty"]:
        szeroko = dl.pivot_table(index=["id_uczestnika", "stimulus_id"],
                                 columns="aoi", values=miara, aggfunc="first")
        szeroko = szeroko.reindex(columns=AOI_WSZYSTKIE)
        szeroko.columns = ["%s__%s" % (miara, c) for c in szeroko.columns]
        baza = baza.merge(szeroko.reset_index(), on=["id_uczestnika", "stimulus_id"], how="left")

    # udziały czasu (normalizacja usuwa wpływ długości ekspozycji)
    for a in AOI_WSZYSTKIE:
        k = "dwell_time__%s" % a
        if k in baza.columns:
            baza["udzial__%s" % a] = baza[k] / baza["dwell_total"].replace(0, np.nan)
    return baza


def modele():
    return {
        "elastic_net": Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("sc", StandardScaler()),
            ("clf", LogisticRegression(penalty="elasticnet", solver="saga", l1_ratio=0.5,
                                       C=0.5, max_iter=5000, random_state=RNG))]),
        "las_losowy": Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("clf", RandomForestClassifier(n_estimators=500, min_samples_leaf=3,
                                           random_state=RNG, n_jobs=-1))]),
        "gradient_boosting": Pipeline([
            ("clf", HistGradientBoostingClassifier(max_iter=300, learning_rate=0.06,
                                                   random_state=RNG))]),
    }


def auc_ci(y, p, n_boot=2000, seed=RNG):
    """Przedział ufności dla AUC metodą bootstrap."""
    rng = np.random.default_rng(seed)
    y, p = np.asarray(y), np.asarray(p)
    out = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        if len(np.unique(y[idx])) < 2:
            continue
        out.append(roc_auc_score(y[idx], p[idx]))
    return float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))


def main():
    ap = argparse.ArgumentParser(description="Klasyfikacja autorstwa ze wzorca skanowania (H9)")
    ap.add_argument("--dane", required=True, help="katalog badanie9_dane")
    ap.add_argument("--wyjscie", default="wyniki")
    ap.add_argument("--tylko-bledne", action="store_true",
                    help="analiza tylko na próbach, w których uczestnik odpowiedział błędnie")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.wyjscie, "ryciny"), exist_ok=True)

    dl = pd.read_csv(os.path.join(a.dane, "05_derived", "dane_analityczne_long.csv"))
    X_all = cechy(dl)
    if a.tylko_bledne:
        X_all = X_all[X_all["q6_poprawnosc"] == 0]
        print("Analiza ograniczona do prób z błędną odpowiedzią: %d" % len(X_all))

    y = (X_all["wariant"] == "AI").astype(int).values
    grupy = X_all["id_uczestnika"].values
    kol = [c for c in X_all.columns if c.startswith(("dwell_time__", "log_ttff__",
                                                     "liczba_fiksacji__", "rewizyty__", "udzial__"))]
    kol += ["dyspersja", "entropia_przejsc", "liczba_przejsc", "liczba_fiksacji_total", "czas_w_tle_proc"]
    kol = [c for c in kol if c in X_all.columns]
    X = X_all[kol].values
    print("Cechy: %d | próby: %d | uczestnicy: %d" % (len(kol), len(X), len(np.unique(grupy))))

    logo = LeaveOneGroupOut()
    wyniki, predykcje = [], {}
    for nazwa, model in modele().items():
        p_out = np.zeros(len(y))
        for tr, te in logo.split(X, y, grupy):
            model.fit(X[tr], y[tr])
            p_out[te] = model.predict_proba(X[te])[:, 1]
        auc = roc_auc_score(y, p_out)
        lo, hi = auc_ci(y, p_out)
        wyniki.append(dict(model=nazwa, auc=round(auc, 4), ci_lo=round(lo, 4), ci_hi=round(hi, 4),
                           n_prob=len(y), n_uczestnikow=len(np.unique(grupy)),
                           powyzej_przypadku=bool(lo > 0.5),
                           kryterium_H9=bool(auc > 0.60 and lo > 0.5)))
        predykcje[nazwa] = p_out
        print("%-20s AUC = %.3f  95%% CI [%.3f; %.3f]" % (nazwa, auc, lo, hi))

    tab = pd.DataFrame(wyniki)
    tab.to_csv(os.path.join(a.wyjscie, "H9_auc.csv"), index=False, encoding="utf-8")

    # ważność cech dla najlepszego modelu (permutacyjna, na pełnym zbiorze)
    najlepszy = tab.sort_values("auc", ascending=False).iloc[0]["model"]
    model = modele()[najlepszy]
    model.fit(X, y)
    imp = permutation_importance(model, X, y, n_repeats=20, random_state=RNG, scoring="roc_auc")
    waz = pd.DataFrame(dict(cecha=kol, waznosc=imp.importances_mean, sd=imp.importances_std)) \
            .sort_values("waznosc", ascending=False)
    waz.to_csv(os.path.join(a.wyjscie, "H9_waznosc_cech.csv"), index=False, encoding="utf-8")
    print("\n15 najważniejszych cech (%s):" % najlepszy)
    print(waz.head(15).to_string(index=False))

    # SHAP, jeśli dostępny
    try:
        import shap
        if najlepszy == "gradient_boosting":
            ex = shap.Explainer(model.named_steps["clf"], X)
            sv = ex(X)
            shap.summary_plot(sv, X, feature_names=kol, show=False, max_display=15)
            import matplotlib.pyplot as plt
            plt.tight_layout()
            plt.savefig(os.path.join(a.wyjscie, "ryciny", "H9_shap.png"), dpi=200)
            plt.close()
            print("Zapisano wykres SHAP.")
    except ImportError:
        print("Pakiet shap niedostępny — pominięto wykres SHAP (pip install shap).")

    # krzywa ROC
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(5.5, 5.5))
        for nazwa, p in predykcje.items():
            fpr, tpr, _ = roc_curve(y, p)
            ax.plot(fpr, tpr, label="%s (AUC = %.3f)" % (nazwa, roc_auc_score(y, p)))
        ax.plot([0, 1], [0, 1], "--", color="grey")
        ax.set_xlabel("Odsetek fałszywych alarmów")
        ax.set_ylabel("Odsetek trafień")
        ax.set_title("Klasyfikacja autorstwa ze wzorca skanowania (H9)\nwalidacja leave-one-participant-out")
        ax.legend(loc="lower right", fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(a.wyjscie, "ryciny", "H9_roc.png"), dpi=200)
        print("Zapisano krzywą ROC.")
    except Exception as e:
        print("Nie udało się narysować krzywej ROC: %s" % e)

    print("\nKryterium H9: AUC > 0,60 przy dolnej granicy przedziału ufności powyżej 0,50.")


if __name__ == "__main__":
    main()
