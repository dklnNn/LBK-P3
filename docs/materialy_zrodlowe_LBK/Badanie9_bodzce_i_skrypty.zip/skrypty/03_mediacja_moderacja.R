# =============================================================================
# Badanie 9 — Reklama AI
# 03_mediacja_moderacja.R — mediacja szeregowa (H10), mediacja przez uwagę,
#                           moderatory indywidualne, ryciny modelu
#
# Wejście : badanie9_dane/05_derived/dane_analityczne_proby.csv
# Wyjście : wyniki/mediacja_*.csv, wyniki/ryciny/*.png
# =============================================================================

pakiety <- c("lme4", "lavaan", "mediation", "dplyr", "tidyr",
             "ggplot2", "readr", "emmeans")
brak <- pakiety[!pakiety %in% rownames(installed.packages())]
if (length(brak)) install.packages(brak, repos = "https://cloud.r-project.org")
invisible(lapply(pakiety, library, character.only = TRUE))

KAT <- Sys.getenv("BADANIE9_DANE", "badanie9_dane")
dir.create("wyniki/ryciny", recursive = TRUE, showWarnings = FALSE)
set.seed(20260726)

dp <- read_csv(file.path(KAT, "05_derived", "dane_analityczne_proby.csv"), show_col_types = FALSE) %>%
  mutate(autorstwo_c = ifelse(wariant == "AI", 0.5, -0.5),
         uczestnik = factor(id_uczestnika), para = factor(para))

# =============================================================================
# 1. Mediacja szeregowa (H10): autorstwo → estetyka → zaufanie → intencja
#    Model wielopoziomowy w lavaan z klastrowaniem po uczestniku.
#    Centrowanie wewnątrzosobowe mediatorów, aby efekty były na poziomie 1.
# =============================================================================
message("=== H10: mediacja szeregowa estetyka → zaufanie → intencja ===")
d <- dp %>%
  group_by(uczestnik) %>%
  mutate(estetyka_c = q2_estetyka - mean(q2_estetyka, na.rm = TRUE),
         zaufanie_c = q3_zaufanie - mean(q3_zaufanie, na.rm = TRUE),
         intencja_c = q4_intencja - mean(q4_intencja, na.rm = TRUE)) %>%
  ungroup() %>%
  filter(!is.na(estetyka_c), !is.na(zaufanie_c), !is.na(intencja_c))

model_med <- '
  estetyka_c ~ a1*autorstwo_c
  zaufanie_c ~ a2*autorstwo_c + d21*estetyka_c
  intencja_c ~ cp*autorstwo_c + b1*estetyka_c + b2*zaufanie_c

  # efekty pośrednie
  ind_est      := a1*b1
  ind_zauf     := a2*b2
  ind_szeregowy := a1*d21*b2
  ind_calkowity := a1*b1 + a2*b2 + a1*d21*b2
  efekt_calkowity := cp + a1*b1 + a2*b2 + a1*d21*b2
'
fit <- sem(model_med, data = d, cluster = "uczestnik", se = "bootstrap", bootstrap = 5000,
           estimator = "ML", missing = "fiml")
wyn <- parameterEstimates(fit, boot.ci.type = "bca.simple", standardized = TRUE)
write_csv(wyn, "wyniki/mediacja_H10.csv")
print(wyn[wyn$op %in% c("~", ":="), c("lhs", "op", "rhs", "label", "est", "se", "ci.lower", "ci.upper", "pvalue")])
cat("\nUwaga: ścieżka bezpośrednia cp (autorstwo → intencja) i ścieżka a2 (autorstwo → zaufanie)\n",
    "są interpretowane osobno — literatura wskazuje na istotny efekt bezpośredni na zaufanie\n",
    "(Miniukovich i Figl, 2023), niezależny od mediacji przez estetykę.\n")

# =============================================================================
# 2. Mediacja przez uwagę: autorstwo → dwell na produkcie → pamięć treści
# =============================================================================
message("\n=== Mediacja przez uwagę: dwell na PRODUKT → pamięć ===")
dl <- read_csv(file.path(KAT, "05_derived", "dane_analityczne_long.csv"), show_col_types = FALSE)
dm <- dl %>% filter(aoi == "PRODUKT") %>%
  select(id_uczestnika, stimulus_id, wariant, dwell_time, q9_poprawnosc) %>%
  mutate(autorstwo_c = ifelse(wariant == "AI", 0.5, -0.5),
         dwell_z = scale(dwell_time)[, 1]) %>%
  filter(!is.na(q9_poprawnosc))

m_med <- lmer(dwell_z ~ autorstwo_c + (1 | id_uczestnika), data = dm)
m_out <- glmer(q9_poprawnosc ~ autorstwo_c + dwell_z + (1 | id_uczestnika),
               data = dm, family = binomial, control = glmerControl(optimizer = "bobyqa"))
med <- mediate(m_med, m_out, treat = "autorstwo_c", mediator = "dwell_z",
               sims = 5000, boot = FALSE)
capture.output(summary(med), file = "wyniki/mediacja_uwaga.txt")
print(summary(med))

# =============================================================================
# 3. Moderatory indywidualne — wprowadzane pojedynczo (ograniczenie mocy)
# =============================================================================
message("\n=== Moderatory indywidualne ===")
moderatory <- c("ai_czestotliwosc_z", "gaais_sr_z", "mails_sr_z", "wiek_z")
wyniki_mod <- list()
for (mo in moderatory) {
  if (!mo %in% names(dp)) next
  f <- as.formula(sprintf("q2_estetyka ~ autorstwo_c * %s + (1 | uczestnik) + (1 | para)", mo))
  m <- lmer(f, data = dp, control = lmerControl(optimizer = "bobyqa"))
  s <- summary(m)$coefficients
  wiersz <- s[grep(":", rownames(s)), , drop = FALSE]
  wyniki_mod[[mo]] <- data.frame(moderator = mo, estymata = wiersz[1, 1],
                                 se = wiersz[1, 2], t = wiersz[1, 3])
  # wykres interakcji: efekty proste przy -1 SD, średniej i +1 SD moderatora
  em <- emmeans(m, ~ autorstwo_c, at = setNames(list(c(-0.5, 0.5), c(-1, 0, 1)),
                                                c("autorstwo_c", mo)), by = mo)
  ramka <- as.data.frame(em)
  names(ramka)[names(ramka) == mo] <- "moderator"
  p <- ggplot(ramka, aes(x = factor(autorstwo_c, labels = c("człowiek", "AI")),
                         y = emmean, group = factor(moderator), colour = factor(moderator))) +
    geom_line(linewidth = 0.9) + geom_point(size = 2) +
    geom_errorbar(aes(ymin = lower.CL, ymax = upper.CL), width = 0.08) +
    labs(x = NULL, y = "Ocena estetyczna (średnia brzegowa)",
         colour = paste(mo, "(SD)"), title = paste("Moderacja:", mo)) +
    theme_minimal(base_size = 12)
  ggsave(sprintf("wyniki/ryciny/moderacja_%s.png", mo), p, width = 6, height = 4.5, dpi = 200)
}
mod_tab <- bind_rows(wyniki_mod)
write_csv(mod_tab, "wyniki/moderatory.csv"); print(mod_tab)

# =============================================================================
# 4. Rycina modelu mediacyjnego
# =============================================================================
sc <- wyn[wyn$label %in% c("a1", "a2", "d21", "b1", "b2", "cp"), c("label", "est", "pvalue")]
write_csv(sc, "wyniki/mediacja_sciezki.csv")
cat("\nWspółczynniki ścieżek do rysunku modelu (ścieżki nieistotne rysować linią przerywaną):\n")
print(sc)

message("\nGotowe. Wyniki w katalogu wyniki/.")
