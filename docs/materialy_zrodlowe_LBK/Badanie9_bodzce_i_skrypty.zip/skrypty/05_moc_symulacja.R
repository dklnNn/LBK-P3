# =============================================================================
# Badanie 9 — Reklama AI
# 05_moc_symulacja.R — symulacyjna analiza mocy dla hipotez H1–H8
# Uruchamiać PRZED złożeniem prerejestracji. Wynik wpisać do załącznika A, punkt 5.
# =============================================================================
pakiety <- c("lme4", "simr", "dplyr", "readr")
brak <- pakiety[!pakiety %in% rownames(installed.packages())]
if (length(brak)) install.packages(brak, repos = "https://cloud.r-project.org")
invisible(lapply(pakiety, library, character.only = TRUE))
set.seed(20260726)

N_UCZ    <- 60      # docelowa liczba uczestników
N_BODZ   <- 40      # liczba bodźców
N_SYM    <- 1000    # liczba symulacji
ICC      <- 0.25    # korelacja wewnątrzosobowa przyjęta a priori
UTRATA   <- 0.10    # zakładany odsetek utraconych prób

# szkielet danych: pełne skrzyżowanie uczestnik × bodziec
szkielet <- expand.grid(uczestnik = factor(1:N_UCZ), bodziec = factor(1:N_BODZ))
szkielet$autorstwo <- ifelse(as.integer(szkielet$bodziec) %% 2 == 0, 0.5, -0.5)
szkielet$nr_proby_z <- as.numeric(scale(ave(rep(1, nrow(szkielet)),
                                            szkielet$uczestnik, FUN = seq_along)))
# losowa utrata prób
szkielet <- szkielet[runif(nrow(szkielet)) > UTRATA, ]

moc_dla_d <- function(d, sd_reszty = 1) {
  # d = wielkość efektu Cohena dla autorstwa
  sd_ucz <- sqrt(ICC / (1 - ICC)) * sd_reszty
  model <- makeLmer(y ~ autorstwo + nr_proby_z + (1 + autorstwo | uczestnik) + (1 | bodziec),
                    fixef = c(0, d, 0),
                    VarCorr = list(uczestnik = matrix(c(sd_ucz^2, 0, 0, (0.5 * sd_ucz)^2), 2),
                                   bodziec = (0.4 * sd_ucz)^2),
                    sigma = sd_reszty, data = szkielet)
  ps <- powerSim(model, test = fixed("autorstwo", "t"), nsim = N_SYM, progress = FALSE)
  s <- summary(ps)
  data.frame(d = d, moc = s$mean, lo = s$lower, hi = s$upper)
}

moc_detekcji <- function(p_traf) {
  # H4: trafność rozpoznania wobec poziomu odniesienia 0,65
  model <- makeGlmer(poprawnosc ~ 1 + (1 | uczestnik) + (1 | bodziec),
                     family = "binomial", fixef = qlogis(p_traf),
                     VarCorr = list(uczestnik = 0.30, bodziec = 0.20),
                     data = transform(szkielet, poprawnosc = 0))
  ps <- powerSim(model, test = fixed("(Intercept)", "z"), nsim = N_SYM, progress = FALSE)
  s <- summary(ps)
  data.frame(p_traf = p_traf, moc = s$mean, lo = s$lower, hi = s$upper)
}

message("Symulacja mocy dla miar ciągłych (H1, H2, H3, H6, H8) ...")
wyn_ciagle <- bind_rows(lapply(c(0.15, 0.20, 0.25, 0.30, 0.40), moc_dla_d))
print(wyn_ciagle)

message("\nSymulacja mocy dla modelu detekcji (H4) ...")
wyn_detekcja <- bind_rows(lapply(c(0.55, 0.58, 0.60, 0.62), moc_detekcji))
print(wyn_detekcja)

dir.create("wyniki", showWarnings = FALSE)
write_csv(wyn_ciagle, "wyniki/moc_miary_ciagle.csv")
write_csv(wyn_detekcja, "wyniki/moc_detekcja.csv")

cat("\nInterpretacja:\n")
cat("  Minimalna interesująca wielkość efektu (SESOI) dla miar okoruchowych: d = 0,20.\n")
cat("  Docelowa moc: 0,80. Jeśli symulacja daje wynik niższy niż deklarowany w prerejestracji,\n")
cat("  należy zwiększyć N albo obniżyć liczbę testowanych hipotez konfirmacyjnych.\n")
cat("  Moderator międzyosobowy (H7) wymaga większej próby — moc szacowana na ok. 0,71 przy N = 60.\n")
